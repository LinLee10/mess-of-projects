package ngordnet.graphs;

import java.util.HashSet;
import java.util.HashMap;
import java.util.Set;

public class DirectedGraph<T> {
    private HashMap<T, HashSet<T>> adjList;
    private int vertices;
    private int edges;

    public DirectedGraph() {
        adjList = new HashMap<>();
        vertices = 0;
        edges = 0;
    }

    /** Creates a vertex V with no initial edges. */
    public void addVertex(T V) {
        if (!adjList.containsKey(V)) {
            adjList.put(V, new HashSet<>());
            vertices += 1;
        }
    }

    /** Creates a vertex V with edge E, can also create vertex E. */
    public void addVertex(T V, T E) {
        if (!adjList.containsKey(V) && !adjList.containsKey(E)) {
            addVertex(V);
            addVertex(E);
            addEdge(V, E);
        } else if (!adjList.containsKey(V) && adjList.containsKey(E)) {
            addVertex(V);
            addEdge(V, E);
        }
    }

    /** Adds an edge from vertex V that points to vertex E, can also create vertex E. */
    public void addEdge(T V, T E) {
        if (!adjList.containsKey(E)) {
            addVertex(E);
            adjList.get(V).add(E);
            edges += 1;
        } else if (!adjList.get(V).contains(E)) {
            adjList.get(V).add(E);
            edges += 1;
        }
    }

    /** Returns all the edges from vertex V. */
    public HashSet<T> connections(T V) {
        return adjList.get(V);
    }

    /** Returns true if the graph contains vertex V. */
    public boolean containsVertex(T V) {
        return adjList.containsKey(V);
    }

    /** Returns a set representation of all vertices in our graph. */
    public Set<T> vertices() {
        return adjList.keySet();
    }

    /** Checks if vertex V and vertex E are connected. */
    public boolean isConnected(T V, T E) {
        return adjList.get(V).contains(E);
    }

    /** Returns the total number of vertices in a graph. */
    public int verticesCount() {
        return vertices;
    }

    /** Returns the total number of edges in a graph. */
    public int edgesCount() {
        return edges;
    }
}

