package ngordnet.graphs;

import org.junit.jupiter.api.Test;

import java.util.HashSet;

import static com.google.common.truth.Truth.assertThat;


public class DirectedGraphTestFile {

    @Test
    /** Tests if our graph can support basic vertices and an edge. */
    public void basicGraphTest() {
        DirectedGraph<String> graph = new DirectedGraph<>();
        HashSet<String> set1 = new HashSet<>();
        HashSet<String> set2 = new HashSet<>();

        set1.add("dog");
        graph.addVertex("cat");
        graph.addVertex("dog");
        graph.addEdge("cat", "dog");
        assertThat(graph.connections("cat")).isEqualTo(set1);

        assertThat(graph.connections("dog")).isEqualTo(set2);

        set2.add("cat");
        graph.addEdge("dog", "cat");
        assertThat(graph.connections("dog")).isEqualTo(set2);
    }

    @Test
    /** Tests if isConnected works properly with one way connections, and also two way connections. */
    public void basicIsConnectedTest() {
        DirectedGraph<String> graph = new DirectedGraph<>();

        graph.addVertex("cat");
        graph.addVertex("dog");
        graph.addEdge("cat", "dog");
        assertThat(graph.isConnected("cat", "dog")).isTrue();
        assertThat(graph.isConnected("dog", "cat")).isFalse();

        graph.addEdge("dog", "cat");
        assertThat(graph.isConnected("dog", "cat")).isTrue();
    }

    @Test
    /** Tests if our graph can support multiple vertices and a complex edge system. */
    public void multipleVerticesTest() {
        DirectedGraph<String> graph = new DirectedGraph<>();

        graph.addVertex("a");
        graph.addVertex("b");
        graph.addVertex("c");
        graph.addVertex("d");
        graph.addVertex("e");
        graph.addEdge("a", "b");
        graph.addEdge("a", "e");
        graph.addEdge("b", "e");
        graph.addEdge("d", "e");
        graph.addEdge("d", "c");
        graph.addEdge("c", "b");
        assertThat(graph.isConnected("a", "b")).isTrue();
        assertThat(graph.isConnected("b", "a")).isFalse();
        assertThat(graph.isConnected("a", "e")).isTrue();
        assertThat(graph.isConnected("e", "a")).isFalse();
        assertThat(graph.isConnected("d", "e")).isTrue();
        assertThat(graph.isConnected("e", "d")).isFalse();
        assertThat(graph.isConnected("c", "b")).isTrue();
        assertThat(graph.isConnected("b", "c")).isFalse();
    }

    @Test
    /** Tests the vertices method, which returns the total number of vertices and edges. */
    public void verticesAndEdgesTest() {
        DirectedGraph<String> graph = new DirectedGraph<>();

        graph.addVertex("1");
        graph.addVertex("2");
        graph.addVertex("3");
        graph.addVertex("4");
        assertThat(graph.verticesCount()).isEqualTo(4);

        graph.addEdge("1", "2");
        graph.addEdge("2", "2");
        graph.addEdge("2", "3");
        graph.addEdge("2", "4");
        graph.addEdge("4", "1");
        assertThat(graph.edgesCount()).isEqualTo(5);
    }

    @Test
    /** Tests if graphs don't contain the same vertex. */
    public void noDuplicateVertices() {
        DirectedGraph<String> graph = new DirectedGraph<>();
        HashSet<String> set = new HashSet<>();

        set.add("b");
        graph.addVertex("s");
        graph.addVertex("b");
        graph.addEdge("s", "b");
        graph.addVertex("s");
        assertThat(graph.connections("s")).isEqualTo(set);
        assertThat(graph.verticesCount()).isEqualTo(2);
    }

    @Test
    /** Tests if graphs only point at the same vertex once. */
    public void noDuplicateEdgesTest() {
        DirectedGraph<String> graph = new DirectedGraph<>();
        HashSet<String> set = new HashSet<>();

        set.add("b");
        graph.addVertex("a");
        graph.addVertex("b");
        graph.addEdge("a", "b");
        graph.addEdge("a", "b");
        assertThat(graph.connections("a")).isEqualTo(set);
    }

    @Test
    /** Tests if containsVertex can tell if a graph contains a vertex. */
    public void containsVertexTest() {
        DirectedGraph<String> graph = new DirectedGraph<>();

        graph.addVertex("a");
        assertThat(graph.containsVertex("a")).isTrue();
        assertThat(graph.containsVertex("b")).isFalse();
    }

    @Test
    /** Tests vertices method in DirectedGraph class. */
    public void verticesTest() {
        DirectedGraph<Integer> graph = new DirectedGraph<>();
        HashSet<Integer> set = new HashSet<>();

        set.add(1);
        set.add(2);
        set.add(3);
        graph.addVertex(1);
        graph.addVertex(2);
        graph.addVertex(3);
        assertThat(graph.vertices()).isEqualTo(set);
    }

    @Test
    /** Tests if we can create a vertex with a starting edge. */
    public void vertexAndEdgeTest() {
        DirectedGraph<Integer> graph = new DirectedGraph<>();
        HashSet<Integer> set1 = new HashSet<>();
        HashSet<Integer> set2 = new HashSet<>();

        graph.addVertex(1, 2);
        assertThat(graph.isConnected(1, 2)).isTrue();
        assertThat(graph.isConnected(2, 1)).isFalse();

        set1.add(2);
        assertThat(graph.connections(1)).isEqualTo(set1);
        assertThat(graph.connections(2)).isEmpty();

        assertThat(graph.verticesCount()).isEqualTo(2);
        assertThat(graph.edgesCount()).isEqualTo(1);

        set2.add(4);
        graph.addVertex(4);
        graph.addVertex(3, 4);
        assertThat(graph.connections(3)).isEqualTo(set2);
        assertThat(graph.connections(4)).isEmpty();

        assertThat(graph.verticesCount()).isEqualTo(4);
        assertThat(graph.edgesCount()).isEqualTo(2);
    }

    @Test
    /** Tests if addEdge can also create vertex E if vertex E doesn't exist. */
    public void addEdgeAndVertexETest() {
        DirectedGraph<Integer> graph = new DirectedGraph<>();
        HashSet<Integer> set = new HashSet<>();

        set.add(2);
        graph.addVertex(1);
        graph.addEdge(1, 2);
        assertThat(graph.connections(1)).isEqualTo(set);
        assertThat(graph.verticesCount()).isEqualTo(2);
        assertThat(graph.edgesCount()).isEqualTo(1);
    }
}
