package ngordnet.wordnet;

import edu.princeton.cs.algs4.In;
import ngordnet.graphs.DirectedGraph;
import ngordnet.ngrams.NGramMap;
import ngordnet.ngrams.TimeSeries;

import java.util.*;

public class WordNet {
    private DirectedGraph<Integer> idGraph;
    private HashMap<Integer, String> idMap;
    private HashMap<String, HashSet<Integer>> wordMap;
    private NGramMap ngram;
    private HashSet<String> hyponymsSet;
    private PriorityQueue<Double> hyponymsQueue;
    private HashMap<Double, HashSet<String>> popularityMap;

    /**
     * Constructs a graph mapping IDs to its children IDs.
     * Creates a HashMap that links IDs to their words.
     * Creates a HashMap that links words to their IDs.
     * */
    public WordNet(String synsetsFile, String hyponymsFile, NGramMap ngrammap) {
        In synsets = new In(synsetsFile);
        In hyponyms = new In(hyponymsFile);
        idGraph = new DirectedGraph<>();
        idMap = new HashMap<>();
        wordMap = new HashMap<>();
        ngram = ngrammap;

        // Maps the id and word together in idMap and vice versa for wordMap
        while (synsets.hasNextLine() && !synsets.isEmpty()) {
            String[] line = synsets.readLine().split(",");
            int id = Integer.parseInt(line[0]);
            String word = line[1];

            if (!idMap.containsKey(id)) {
                idMap.put(id, word);
            }

            String[] words = word.split(" ");
            for (String w : words) {
                if (!wordMap.containsKey(w)) {
                    HashSet<Integer> ids = new HashSet<>();
                    ids.add(id);
                    wordMap.put(w, ids);
                } else {
                    wordMap.get(w).add(id);
                }
            }
        }

        // Creates a graph with id, and creates edges with all of its children
        while (hyponyms.hasNextLine() && !hyponyms.isEmpty()) {
            String[] line = hyponyms.readLine().split(",");
            int parentId = Integer.parseInt(line[0]);

            if (!idGraph.containsVertex(parentId)) {
                idGraph.addVertex(parentId);
            }

            if (line.length > 1) {
                for (int i = 1; i < line.length; i++) {
                    int child = Integer.parseInt(line[i]);
                    if (!idGraph.containsVertex(child)) {
                        idGraph.addVertex(child);
                    }
                    idGraph.addEdge(parentId, child);
                }
            }
        }
    }

    /**
     * Tests if the graph is constructed properly, made for testing.
     * Should really be made private, but I want test file to access it.
     */
    public DirectedGraph<Integer> idGraphTest() {
        return idGraph;
    }

    /**
     * Tests if the idMap is constructed properly, made for testing.
     * Should really be made private, but I want test file to access it.
     */
    public HashMap<Integer, String> idMapTest() {
        return idMap;
    }

    /**
     * Tests if the wordMap is constructed properly, made for testing.
     * Should really be made private, but I want test file to access it.
     */
    public HashMap<String, HashSet<Integer>> wordMapTest() {
        return wordMap;
    }

    /**
     * Takes in an ID and returns its respective word.
     */
    public String getWord(int id) {
        return idMap.get(id);
    }

    /**
     * Takes in a word and returns its respective ID, if a word has no ID, it returns an empty HashSet.
     */
    public HashSet<Integer> getID(String word) {
        if (wordMap.get(word) != null) {
            return wordMap.get(word);
        } else {
            return new HashSet<>();
        }
    }

    /**
     * Returns the total count history of a word.
     */
    public double sumCountHistory(String word, int startYear, int endYear) {
        TimeSeries ts = ngram.countHistory(word, startYear, endYear);
        double sum = 0.0;
        for (int i = startYear; i <= endYear; i++) {
            if (ts.get(i) != null) {
                sum += ts.get(i);
            }
        }
        return sum;
    }

    /**
     * Splits words into a word list, to account for multiple words. Then adds it to a set of hyponyms.
     * If k != 0, then it adds it to a popularity map and creates a HashSet (or adds to it if it exists)
     */
    private void hyponymRetriever(int id, int startYear, int endYear, int k) {
        String[] words = getWord(id).split(" ");
        for (String word : words) {
            hyponymsSet.add(word);
            if (k > 0) {
                double count = sumCountHistory(word, startYear, endYear);
                if (!popularityMap.containsKey(count)) {
                    HashSet<String> popWords = new HashSet<>();
                    popWords.add(word);
                    popularityMap.put(count, popWords);
                } else {
                    popularityMap.get(count).add(word);
                }
                hyponymsQueue.add(count);
            }
        }
    }

    /**
     * Recurses through a list of connections to obtain the hyponyms of all words belonging to a parent word.
     * Includes start year and end year.
     */
    private void getHyponymsHelper(HashSet<Integer> ids, int startYear, int endYear, int k) {
        if (!ids.isEmpty()) {
            for (Integer id : ids) {
                hyponymRetriever(id, startYear, endYear, k);
                getHyponymsHelper(idGraph.connections(id), startYear, endYear, k);
            }
        }
    }

    /**
     * Returns a count that isn't already in a set of counts.
     */
    public double countHelper(HashSet<Double> counts) {
        double count = hyponymsQueue.remove();
        while (counts.contains(count) && !hyponymsQueue.isEmpty()) {
            count = hyponymsQueue.remove();
        }
        counts.add(count);
        return count;
    }

    /**
     * Gets the k most popular words and returns it.
     */
    public HashSet<String> kHelper(HashSet<String> wordSet, int k) {
        int i = 0;
        HashSet<Double> counts = new HashSet<>();
        HashSet<String> popularitySet = new HashSet<>();
        while (i < k) {
            if (!hyponymsQueue.isEmpty()) {
                double count = countHelper(counts);
                HashSet<String> words = popularityMap.get(count);
                for (String word : words) {
                    if (wordSet.contains(word)) {
                        if (i < k && !(count == 0.0)) {
                            popularitySet.add(word);
                        }
                        i += 1;
                    }
                }
            } else {
                break;
            }
        }
        wordSet.retainAll(popularitySet);
        return wordSet;
    }

    /**
     * Takes in a hyponymsList and determines if k != 0, returns a list of hyponyms.
     */
    public HashSet<String> kChecker(HashSet<String> words, int k) {
        if (k > 0) {
            return kHelper(words, k);
        } else {
            return words;
        }
    }

    /**
     * Returns the hyponyms of a word and its children's hyponyms.
     * Includes startYear, endYear, and k.
     */
    public HashSet<String> getHyponyms(HashSet<Integer> ids, int startYear, int endYear, int k) {
        hyponymsSet = new HashSet<>();
        hyponymsQueue = new PriorityQueue<>(Comparator.reverseOrder());
        popularityMap = new HashMap<>();

        getHyponymsHelper(ids, startYear, endYear, k);

        return hyponymsSet;
    }

    /**
     * Takes in a list of words and returns the shared hyponyms between them.
     * Includes startYear, endYear, and k.
     */
    public HashSet<String> getMultipleHyponyms(HashSet<String> words, int startYear, int endYear, int k) {
        HashSet<String> intersection = new HashSet<>();

        for (String word : words) {
            HashSet<String> currentWords = getHyponyms(getID(word), startYear, endYear, k);
            if (intersection.isEmpty()) {
                intersection.addAll(currentWords);
            } else {
                intersection.retainAll(currentWords);
            }
        }

        return intersection;
    }
}
