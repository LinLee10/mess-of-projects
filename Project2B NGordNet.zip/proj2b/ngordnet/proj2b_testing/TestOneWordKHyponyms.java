package ngordnet.proj2b_testing;

import ngordnet.browser.NgordnetQuery;
import ngordnet.browser.NgordnetQueryHandler;
import org.junit.jupiter.api.Test;

import java.util.List;

import static com.google.common.truth.Truth.assertThat;

/** Tests the most basic case for Hyponyms where the list of words is one word long, and k = 0.*/
public class TestOneWordKHyponyms {
    // this case doesn't use the NGrams dataset at all, so the choice of files is irrelevant
    public static final String WORDS_FILE = "data/ngrams/very_short.csv";
    public static final String TOTAL_COUNTS_FILE = "data/ngrams/total_counts.csv";
    public static final String SMALL_SYNSET_FILE = "data/wordnet/synsets16.txt";
    public static final String SMALL_HYPONYM_FILE = "data/wordnet/hyponyms16.txt";
    public static final String BIG_WORDS_FILE = "data/ngrams/top_14377_words.csv";
    public static final String BIG_SYNSETS = "data/wordnet/synsets.txt";
    public static final String BIG_HYPONYMS = "data/wordnet/hyponyms.txt";

    @Test
    public void basicCreatureKTest() {
        NgordnetQueryHandler studentHandler = AutograderBuddy.getHyponymHandler(
                BIG_WORDS_FILE, TOTAL_COUNTS_FILE, BIG_SYNSETS, BIG_HYPONYMS);
        List<String> words = List.of("creature");

        NgordnetQuery nq = new NgordnetQuery(words, 1470, 2019, 3);
        String actual = studentHandler.handle(nq);
        String expected = "[head, man, world]";
        assertThat(actual).isEqualTo(expected);
    }

    @Test
    public void basicGenusKTest() {
        NgordnetQueryHandler studentHandler = AutograderBuddy.getHyponymHandler(
                BIG_WORDS_FILE, TOTAL_COUNTS_FILE, BIG_SYNSETS, BIG_HYPONYMS);
        List<String> words = List.of("genus");

        NgordnetQuery nq = new NgordnetQuery(words, 1470, 2019, 2);
        String actual = studentHandler.handle(nq);
        String expected = "[genus]";
        assertThat(actual).isEqualTo(expected);
    }

    @Test
    public void largeMunicipalityKTest() {
        NgordnetQueryHandler studentHandler = AutograderBuddy.getHyponymHandler(
                BIG_WORDS_FILE, TOTAL_COUNTS_FILE, BIG_SYNSETS, BIG_HYPONYMS);
        List<String> words = List.of("municipality");

        NgordnetQuery nq = new NgordnetQuery(words, 1470, 2019, 8);
        String actual = studentHandler.handle(nq);
        String expected = "[borough, city, municipality, town]";
        assertThat(actual).isEqualTo(expected);
    }
}
