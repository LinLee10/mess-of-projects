package byow.Core;

import byow.TileEngine.TETile;

public class Pairs {
    private TETile[][] myTile;
    private String keyString;

    public Pairs(TETile[][] myTile, String keyString) {
        this.myTile = myTile;
        this.keyString = keyString;
    }

    public TETile[][] getFirst() {
        return myTile;
    }

    public String getSecond() {
        return keyString;
    }
}
