package byow.InputDemo;

/**
 * Created by hug.
 */
import byow.TileEngine.TERenderer;
import byow.TileEngine.TETile;
import byow.TileEngine.Tileset;
import edu.princeton.cs.algs4.StdDraw;

import java.awt.*;

public class KeyboardInputSource implements InputSource {
    private static final boolean PRINT_TYPED_KEYS = false;

    public KeyboardInputSource() {
        StdDraw.text(0.3, 0.3, "press m to moo, q to quit");
    }

    public char getNextKey() {
        while (true) {
            if (StdDraw.hasNextKeyTyped()) {
                char c = Character.toUpperCase(StdDraw.nextKeyTyped());
                if (PRINT_TYPED_KEYS) {
                    System.out.print(c);
                }
                return c;
            }
        }
    }

    public char getNextMove(TERenderer myRender, TETile[][] myTiles, String avatarName) {
        StdDraw.setPenColor(Color.WHITE);
        Font font = new Font("Monaco", Font.BOLD, 16 - 2);
        StdDraw.setFont(font);
        while (true) {
            if (!StdDraw.hasNextKeyTyped()) {
                myRender.renderFrame(myTiles);
                StdDraw.setPenColor(Color.WHITE);
                int mouseX = (int) StdDraw.mouseX();
                int mouseY = (int) StdDraw.mouseY();
                if (mouseX < myTiles.length && mouseY < myTiles[0].length) {
                    if (myTiles[mouseX][mouseY] == Tileset.FLOOR) {
                        StdDraw.text(40, 32, "OPEN");
                    } else if (myTiles[mouseX][mouseY] == Tileset.WALL) {
                        StdDraw.text(40, 32, "WALL");
                    } else if (myTiles[mouseX][mouseY] == Tileset.AVATAR) {
                        StdDraw.text(40, 32, "YOU");
                    } else {
                        StdDraw.text(40, 32, "NOTHING");
                    }
                }
                StdDraw.text(60, 32, avatarName);
                StdDraw.show();
            }
            else {
                char c = Character.toUpperCase(StdDraw.nextKeyTyped());
                if (PRINT_TYPED_KEYS) {
                    System.out.print(c);
                }
                return c;
            }
        }
    }

    public char getNextMove(TERenderer myRender, TETile[][] myTiles) {
        StdDraw.setPenColor(Color.WHITE);
        Font font = new Font("Monaco", Font.BOLD, 16 - 2);
        StdDraw.setFont(font);
        while (true) {
            if (!StdDraw.hasNextKeyTyped()) {
                myRender.renderFrame(myTiles);
                StdDraw.setPenColor(Color.WHITE);
                int mouseX = (int) StdDraw.mouseX();
                int mouseY = (int) StdDraw.mouseY();
                if (mouseX < myTiles.length && mouseY < myTiles[0].length) {
                    if (myTiles[mouseX][mouseY] == Tileset.FLOOR) {
                        StdDraw.text(40, 32, "OPEN");
                    } else if (myTiles[mouseX][mouseY] == Tileset.WALL) {
                        StdDraw.text(40, 32, "WALL");
                    } else if (myTiles[mouseX][mouseY] == Tileset.AVATAR) {
                        StdDraw.text(40, 32, "YOU");
                    } else {
                        StdDraw.text(40, 32, "NOTHING");
                    }
                }
                StdDraw.show();
            }
            else {
                char c = Character.toUpperCase(StdDraw.nextKeyTyped());
                if (PRINT_TYPED_KEYS) {
                    System.out.print(c);
                }
                return c;
            }
        }
    }

    public boolean possibleNextInput() {
        return true;
    }
}
