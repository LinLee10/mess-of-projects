package ngordnet.main;

import ngordnet.browser.NgordnetQuery;
import ngordnet.browser.NgordnetQueryHandler;
import ngordnet.wordnet.WordNet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class HyponymsHandler extends NgordnetQueryHandler {

    private WordNet wordnet;

    public HyponymsHandler(WordNet wordnet) {
        this.wordnet = wordnet;
    }

    @Override
    public String handle(NgordnetQuery q) {
        if (q.words().size() > 1) {
            // Obtaining list of words
            HashSet<String> words = new HashSet<>();
            words.addAll(q.words());

            // Retrieving the hyponyms and checking for k.
            HashSet<String> wordnetWords = wordnet.getMultipleHyponyms(words, q.startYear(), q.endYear(), q.k());
            HashSet<String> kCheckedWords = wordnet.kChecker(wordnetWords, q.k());

            return setHelper(kCheckedWords);
        } else {
            // Obtaining list of ids
            HashSet<Integer> ids = idHelper(q.words());

            // Creating the list and sorting the list to return
            HashSet<String> wordnetWords = wordnet.getHyponyms(ids, q.startYear(), q.endYear(), q.k());
            HashSet<String> kCheckedWords = wordnet.kChecker(wordnetWords, q.k());

            return setHelper(kCheckedWords);
        }
    }

    /**
     * Gets a list of words and returns a hashset of their IDs.
     */
    public HashSet<Integer> idHelper(List<String> words) {
        HashSet<Integer> ids = new HashSet<>();
        for (String word : words) {
            HashSet<Integer> id = wordnet.getID(word);
            ids.addAll(id);
        }
        return ids;
    }

    /**
     * Takes in a hashSet and adds it all to a sorted arraylist to return in string format.
     */
    public String setHelper(HashSet<String> words) {
        ArrayList<String> wordList = new ArrayList<>();
        wordList.addAll(words);
        Collections.sort(wordList);
        return wordList.toString();
    }
}
