package byow.Core;
import byow.TileEngine.TERenderer;
import byow.TileEngine.TETile;
import byow.TileEngine.Tileset;

import java.util.*;
import java.util.Random;


public class Rooms {

    Random rand;
    public static final int DEF_PARENT = 1000;
    public static final int MIN_ROOM = 20;
    public static final int MAX_ROOM = 30;
    private class Room {
        int id, w, l, x, y;
        public Room(int id, int w, int l, int x, int y) {
            this.id = id;
            this.w = w;
            this.l = l;
            this.x = x;
            this.y = y;
        }

        public int getX() {
            return x;
        }

        public int getY() {
            return y;
        }


    }
    private TETile[][] myTile;

    private int[][] myTileType;
    private List<Room> roomList;

    private int[] parent;

    private int avatarH, avatarV;
    public Rooms(TETile[][] t, long seed) {
        rand = new Random();
        rand.setSeed(seed);
        myTile = t;
        myTileType = new int[t.length][t[0].length];
        for (int curx = 0; curx < t.length; curx++) {
            for (int cury = 0; cury < t[0].length; cury++) {
                myTile[curx][cury] = Tileset.NOTHING;
                myTileType[curx][cury] = -1;
            }
        }
        roomList = new ArrayList<>();
        parent = new int[DEF_PARENT];
        for (int i = 0; i < parent.length; i++) {
            parent[i] = i;
        }
    }
    public boolean overlap(Room a, Room b) {
        if (a.x < b.x + b.w + 2 && b.x < a.x + a.w + 2 && a.y < b.y + b.l + 2 && b.y < a.y + a.l + 2) {
            return true;
        }
        return false;
    }

    public void addRoom() {
        int w = 2 + rand.nextInt(4);
        int l = 2 + rand.nextInt(4);
        int x = 1 + rand.nextInt(myTile.length - 6);
        int y = 1 + rand.nextInt(myTile[0].length - 6);
        Room newRoom = new Room(roomList.size() + 1, w, l, x, y);
        boolean overlaps = false;
        for (Room r: roomList) {
            if (overlap(newRoom, r)) {
                overlaps = true;
            }
        }
        if (!overlaps) {
            roomList.add(newRoom);
            for (int curx = x; curx < x + w; curx++) {
                for (int cury = y; cury < y + l; cury++) {
                    myTile[curx][cury] = Tileset.FLOOR;
                    myTileType[curx][cury] = roomList.size();
                }
            }
        }
    }

    public void makeRooms() {
        int numberOfRooms = rand.nextInt(MIN_ROOM, MAX_ROOM);
        while (roomList.size() < numberOfRooms) {
            addRoom();
        }
    }

    public TETile[][] getTile() {
        return myTile;
    }

    public void addHallways() {
        drawHorizontalHalls();
        drawVerticalHalls();
        drawHorizontalHalls();
        delete();


        /*
        for (int i = 1; i < myTile.length - 1; i++) {
            for (int j = 1; j < myTile[0].length - 1; j++) {
                if (myTileType[i][j-1] > 0 && myTileType[i][j+1] > 0) {
                    myTile[i][j] = Tileset.FLOOR;
                    myTileType[i][j] = myTileType[i][j-1];
                    connect(myTileType[i][j-1], myTileType[i][j+1]);
                }
            }
        }

        for (int i = 1; i < myTile.length - 1; i++) {
            for (int j = 1; j < myTile[0].length - 1; j++) {
                if (myTileType[i-1][j] > 0 && myTileType[i+1][j] > 0) {
                    myTile[i][j] = Tileset.FLOOR;
                    myTileType[i][j] = myTileType[i-1][j];
                    connect(myTileType[i-1][j], myTileType[i+1][j]);
                }
            }
        }
        */



        for (int i = 0; i < myTile.length; i += 1) {
            for (int j = 0; j < myTile[0].length; j += 1) {
                if ((i >= 1 && myTile[i - 1][j] == Tileset.FLOOR)) {
                    if (myTile[i][j] != Tileset.FLOOR) {
                        myTile[i][j] = Tileset.WALL;
                    }
                } else if ((i < myTile.length - 1 && myTile[i + 1][j] == Tileset.FLOOR)) {
                    if (myTile[i][j] != Tileset.FLOOR) {
                        myTile[i][j] = Tileset.WALL;
                    }
                } else if ((j >= 1 && myTile[i][j - 1] == Tileset.FLOOR)) {
                    if (myTile[i][j] != Tileset.FLOOR) {
                        myTile[i][j] = Tileset.WALL;
                    }
                } else if ((j < myTile[0].length - 1 && myTile[i][j + 1] == Tileset.FLOOR)) {
                    if (myTile[i][j] != Tileset.FLOOR) {
                        myTile[i][j] = Tileset.WALL;
                    }
                } else if ((i < myTile.length - 1 && j < myTile[0].length - 1
                        && myTile[i + 1][j + 1] == Tileset.FLOOR)) {
                    if (myTile[i][j] != Tileset.FLOOR) {
                        myTile[i][j] = Tileset.WALL;
                    }
                } else if ((i < myTile.length - 1 && j > 0 && myTile[i + 1][j - 1] == Tileset.FLOOR)) {
                    if (myTile[i][j] != Tileset.FLOOR) {
                        myTile[i][j] = Tileset.WALL;
                    }
                } else if ((i > 0 && j < myTile[0].length - 1 && myTile[i - 1][j + 1] == Tileset.FLOOR)) {
                    if (myTile[i][j] != Tileset.FLOOR) {
                        myTile[i][j] = Tileset.WALL;
                    }
                } else if ((i > 0 && j > 0 && myTile[i - 1][j - 1] == Tileset.FLOOR)) {
                    if (myTile[i][j] != Tileset.FLOOR) {
                        myTile[i][j] = Tileset.WALL;
                    }
                }
            }
        }



    }

    public boolean isGoodH(int a, int b) {
        if (myTileType[a][b] == -1 && b >= 2 && myTileType[a][b - 1] == -1
                && myTileType[a][b - 2] == -1 && b < myTile[0].length - 2
                && myTileType[a][b + 1] == -1 && myTileType[a][b + 2] == -1) {
            return true;
        }
        return false;
    }

    public void drawHorizontalHalls() {
        for (int j = 0; j < myTile[0].length; j++) {
            int i = 0;
            boolean isGoing = false;
            int start = 0;
            int startRoom = 0;
            while (i < myTile.length) {
                if (!isGoing) {
                    if (myTile[i][j] == Tileset.NOTHING && i >= 1 && myTileType[i - 1][j] > 0 && isGoodH(i, j)) {
                        isGoing = true;
                        start = i;
                        startRoom = myTileType[i - 1][j];
                    }
                } else if (!isGoodH(i, j)) {
                    isGoing = false;
                } else if (i < myTile.length - 1 && myTileType[i + 1][j] > 0
                        && !isConnected(startRoom, myTileType[i + 1][j])) {
                    for (int init = start; init <= i; init++) {
                        myTile[init][j] = Tileset.FLOOR;
                        myTileType[init][j] = startRoom;
                    }
                    connect(startRoom, myTileType[i + 1][j]);
                }
                i++;
            }
        }
    }

    public void drawVerticalHalls() {
        for (int i = 0; i < myTile.length; i++) {
            int j = 0;
            boolean isGoing = false;
            int start = 0;
            int startRoom = 0;
            while (j < myTile[0].length) {
                if (!isGoing) {
                    if (myTileType[i][j] == -1 && j >= 1 && myTileType[i][j - 1] > 0 && isGoodV(i, j)) {
                        isGoing = true;
                        start = j;
                        startRoom = myTileType[i][j - 1];
                    }
                } else if (!isGoodV(i, j)) {
                    isGoing = false;
                } else if (j < myTile[0].length - 1 && myTileType[i][j + 1] > 0
                        && !isConnected(startRoom, myTileType[i][j + 1])) {
                    for (int init = start; init <= j; init++) {
                        myTile[i][init] = Tileset.FLOOR;
                        myTileType[i][init] = startRoom;
                    }
                    connect(startRoom, myTileType[i][j + 1]);
                }
                j++;
            }
        }
    }

    public boolean isGoodV(int a, int b) {
        if (myTileType[a][b] == -1 && a >= 2 && myTileType[a - 1][b] == -1
                && myTileType[a - 2][b] == -1 && a < myTile.length - 2
                && myTileType[a + 1][b] == -1 && myTileType[a + 2][b] == -1) {
            return true;
        }
        return false;
    }

    public boolean isConnected(int a, int b) {
        if (find(a) == find(b)) {
            return true;
        }
        return false;
    }

    public int check() {
        int correctFind = find(1);
        for (int i = 2; i < roomList.size() + 1; i++) {
            if (find(i) != correctFind) {
                return i;
            }
        }
        return 0;
    }

    public void delete() {
        Map<Integer, ArrayList<Integer>> myMap = new HashMap<>();
        for (int i = 1; i <=  roomList.size(); i++) {
            if (myMap.containsKey(find(i))) {
                myMap.get(find(i)).add(i);
            } else {
                myMap.put(find(i), new ArrayList<>());
                myMap.get(find(i)).add(i);
            }
        }
        int curMax = 0;
        int curMaxSize = 0;
        for (Integer a: myMap.keySet()) {
            if (myMap.get(a).size() > curMaxSize) {
                curMax = a;
                curMaxSize = myMap.get(a).size();
            }
        }
        for (Integer a: myMap.keySet()) {
            if (a != curMax) {
                floodDelete(a);
                for (Integer b: myMap.get(a)) {
                    for (Room r: roomList) {
                        if (r.id == b) {
                            roomList.remove(r);
                            break;
                        }
                    }
                }
            }
        }
    }

    public void floodDelete(int a) {
        for (int i = 0; i < myTile.length; i++) {
            for (int j = 0; j < myTile[0].length; j++) {
                if (myTileType[i][j] > 0 && find(myTileType[i][j]) == a) {
                    myTile[i][j] = Tileset.NOTHING;
                    myTileType[i][j] = -1;
                }
            }
        }
    }

    public int find(int node) {
        if (parent[node] == node) {
            return node;
        }
        return find(parent[node]);
    }

    public void connect(int a, int b) {
        parent[find(b)] = find(a);
    }

    public int size() {
        return roomList.size();
    }
    public void output() {
        for (int j = 0; j < myTile[0].length; j++) {
            for (int i = 0; i < myTile.length; i++) {
                System.out.print(myTileType[i][myTile[0].length - 1 - j] + " ");
            }
            System.out.println();
        }
        System.out.println(roomList.size());
        TERenderer ter = new TERenderer();
        ter.initialize(myTile.length, myTile[0].length);
        ter.renderFrame(myTile);
    }
    public void findRandomTile() {
        int count = 0;
        for (int j = 0; j < myTile[0].length; j++) {
            for (int i = 0; i < myTile.length; i++) {
                if (myTile[i][j] == Tileset.FLOOR) {
                    count++;
                }
            }
        }
        int theOne = rand.nextInt(count);
        count = 0;
        for (int j = 0; j < myTile[0].length; j++) {
            for (int i = 0; i < myTile.length; i++) {
                if (myTile[i][j] == Tileset.FLOOR) {
                    if (count == theOne) {
                        this.avatarH = i;
                        this.avatarV = j;
                        myTile[i][j] = Tileset.AVATAR;
                        return;
                    }
                    count++;
                }
            }
        }
    }

    public int getAvatarH () {
        return avatarH;
    }

    public int getAvatarV () {
        return avatarV;
    }
    public int moveUp(TETile[][] myTile, int avatarH, int avatarV) {
        if (myTile[avatarH][avatarV+1] == Tileset.FLOOR) {
            myTile[avatarH][avatarV] = Tileset.FLOOR;
            myTile[avatarH][avatarV+1] = Tileset.AVATAR;
            avatarV++;
        }
        return avatarV;
    }

    public int moveDown(TETile[][] myTile, int avatarH, int avatarV) {
        if (myTile[avatarH][avatarV-1] == Tileset.FLOOR) {
            myTile[avatarH][avatarV] = Tileset.FLOOR;
            myTile[avatarH][avatarV-1] = Tileset.AVATAR;
            avatarV--;
        }
        return avatarV;
    }

    public int moveLeft(TETile[][] myTile, int avatarH, int avatarV) {
        if (myTile[avatarH-1][avatarV] == Tileset.FLOOR) {
            myTile[avatarH][avatarV] = Tileset.FLOOR;
            myTile[avatarH-1][avatarV] = Tileset.AVATAR;
            avatarH--;
        }
        return avatarH;
    }

    public int moveRight(TETile[][] myTile, int avatarH, int avatarV) {
        if (myTile[avatarH+1][avatarV] == Tileset.FLOOR) {
            myTile[avatarH][avatarV] = Tileset.FLOOR;
            myTile[avatarH+1][avatarV] = Tileset.AVATAR;
            avatarH++;
        }
        return avatarH;
    }


}
