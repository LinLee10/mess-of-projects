package byow.Core;

import byow.InputDemo.KeyboardInputSource;
import byow.InputDemo.StringInputDevice;
import byow.TileEngine.TERenderer;
import byow.TileEngine.TETile;
import byow.TileEngine.Tileset;
import edu.princeton.cs.algs4.StdDraw;

import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Engine {
    TERenderer ter = new TERenderer();
    /* Feel free to change the width and height. */
    public static final int WIDTH = 80;
    public static final int HEIGHT = 30;
    public static final int FORTY = 40;
    public static final int SIXTY = 60;
    public static final int FIFTY = 50;
    public static final int THIRTY = 30;
    public static final int TWENTY = 20;
    public static final int SIXHUNDRED = 600;
    public static final int ONEHUNDRED = 100;
    public static final int EIGHTY = 80;
    public static final int SIXTEEN = 16;
    int avatarH;
    int avatarV;


    /**
     * Method used for exploring a fresh world. This method should handle all inputs,
     * including inputs from the main menu.
     */
    public void interactWithKeyboard() {
        drawBasic();
        KeyboardInputSource collin = new KeyboardInputSource();
        boolean rendered = false;
        String keys = "";
        String avatarName = "";
        TETile[][] myloadedTile = null;
        Rooms myRooms = new Rooms(new TETile[WIDTH][HEIGHT], 0);
        while (!rendered) {
            char firstChar = collin.getNextKey();
            keys += firstChar;
            if (firstChar == 'Q') {
                return;
            } else if (firstChar == 'N' || firstChar == 'L') {
                Pairs myRet = newOrLoad(collin, keys, firstChar);
                myloadedTile = myRet.getFirst();
                keys = myRet.getSecond();
                rendered = true;
            } else if (firstChar == 'A') {
                keys = "";
                avatarName = avatarProcess(collin);
            }
        }
        int[] avatarCoordinates = checkAvatar(myloadedTile);
        avatarH = avatarCoordinates[0];
        avatarV = avatarCoordinates[1];
        boolean toggle = false;
        TETile[][] toggleTile = new TETile[myloadedTile.length][myloadedTile[0].length];
        while (true) {
            StdDraw.pause(FIFTY);
            if (!toggle) {
                char myChar;
                if (!avatarName.equals("")) {
                    myChar = collin.getNextMove(ter, myloadedTile, avatarName);
                } else {
                    myChar = collin.getNextMove(ter, myloadedTile);
                }
                keys += myChar;
                if (myChar == ':') {
                    keys = keys.substring(0, keys.length() - 1);
                    myChar = collin.getNextKey();
                    if (myChar == 'Q') {
                        writeFile(keys);
                        return;
                    }
                } else {
                    Complex me = processChar(myChar, avatarV, avatarH, myRooms, myloadedTile, keys, toggleTile);
                    avatarV = me.getAvatarV();
                    avatarH = me.getAvatarH();
                    keys = me.getKeyString();
                    toggle = me.getToggle();
                }
            } else {
                char myChar;
                if (!avatarName.equals("")) {
                    myChar = collin.getNextMove(ter, toggleTile, avatarName);
                } else {
                    myChar = collin.getNextMove(ter, toggleTile);
                }
                keys += myChar;
                if (myChar == ':') {
                    keys = keys.substring(0, keys.length() - 1);
                    myChar = collin.getNextKey();
                    if (myChar == 'Q') {
                        writeFile(keys);
                        return;
                    }
                } else {
                    Complex me = processCharToggled(myChar, avatarV, avatarH, myRooms, myloadedTile, keys, toggleTile);
                    avatarH = me.getAvatarH();
                    avatarV = me.getAvatarV();
                    keys = me.getKeyString();
                    toggle = me.getToggle();
                }
            }
        }
    }
    /**
     * Method used for autograding and testing your code. The input string will be a series
     * of characters (for example, "n123sswwdasdassadwas", "n123sss:q", "lwww". The engine should
     * behave exactly as if the user typed these characters into the engine using
     * interactWithKeyboard.
     *
     * Recall that strings ending in ":q" should cause the game to quite save. For example,
     * if we do interactWithInputString("n123sss:q"), we expect the game to run the first
     * 7 commands (n123sss) and then quit and save. If we then do
     * interactWithInputString("l"), we should be back in the exact same state.
     *
     * In other words, running both of these:
     *   - interactWithInputString("n123sss:q")
     *   - interactWithInputString("lww")
     *
     * should yield the exact same world state as:
     *   - interactWithInputString("n123sssww")
     *
     * @param input the input string to feed to your program
     * @return the 2D TETile[][] representing the state of the world
     */
    public TETile[][] interactWithInputString(String input) {
        drawBasicInputString();
        StringInputDevice collin = new StringInputDevice(input);
        boolean rendered = false;
        Rooms myRooms = new Rooms(new TETile[WIDTH][HEIGHT], 0);
        String thisString = input;
        String hi = "";
        TETile[][] myloadedTile = new TETile[myRooms.getTile().length][myRooms.getTile()[0].length];
        while (!rendered) {
            char firstChar = collin.getNextKey();
            if (firstChar == 'Q') {
                return null;
            } else if (firstChar == 'N') {
                drawRandomSeed();
                String curSeed = "";
                while (!rendered) {
                    char myChar = collin.getNextKey();
                    if (myChar != 'S') {
                        curSeed = curSeed + myChar;
                        StdDraw.clear(Color.BLACK);
                        StdDraw.text(FIFTY, EIGHTY, curSeed);
                    } else {
                        myRooms = new Rooms(new TETile[WIDTH][HEIGHT], Long.parseLong(curSeed));
                        myRooms.makeRooms();
                        myRooms.addHallways();
                        myRooms.findRandomTile();
                        ter.initialize(myRooms.getTile().length, myRooms.getTile()[0].length);
                        rendered = true;
                        myloadedTile = myRooms.getTile();
                        ter.renderFrame(myloadedTile);
                    }
                }
            } else if (firstChar == 'L') {
                thisString = thisString.substring(1);
                Scanner scanner = null;
                try {
                    scanner = new Scanner(new File("myfile.txt"));
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
                hi = scanner.next();
                myloadedTile = interactWithInputString(hi);
                ter.renderFrame(myloadedTile);
                rendered = true;
            }
        }
        for (int i = 0; i < myloadedTile.length; i++) {
            for (int j = 0; j < myloadedTile[0].length; j++) {
                if (myloadedTile[i][j] == Tileset.AVATAR) {
                    avatarH = i;
                    avatarV = j;
                }
            }
        }
        while (collin.possibleNextInput()) {
            char myChar = collin.getNextKey();
            if (myChar == 'W') {
                avatarV = myRooms.moveUp(myloadedTile, avatarH, avatarV);
                ter.renderFrame(myloadedTile);
            } else if (myChar == 'A') {
                avatarH = myRooms.moveLeft(myloadedTile, avatarH, avatarV);
                ter.renderFrame(myloadedTile);
            } else if (myChar == 'S') {
                avatarV = myRooms.moveDown(myloadedTile, avatarH, avatarV);
                ter.renderFrame(myloadedTile);
            } else if (myChar == 'D') {
                avatarH = myRooms.moveRight(myloadedTile, avatarH, avatarV);
                ter.renderFrame(myloadedTile);
            } else if (myChar == ':') {
                myChar = collin.getNextKey();
                if (myChar == 'Q') {
                    writeFileInputString(hi, thisString);
                    return myloadedTile;
                }
            }
            ter.renderFrame(myloadedTile);
        }
        return myloadedTile;
    }

    public void drawBasic() {
        StdDraw.setCanvasSize(SIXHUNDRED, SIXHUNDRED);
        StdDraw.setXscale(0, ONEHUNDRED);
        StdDraw.setYscale(0, ONEHUNDRED);
        StdDraw.clear(Color.BLACK);

        // set font size and style
        Font font = new Font("Arial", Font.BOLD, SIXTY);
        StdDraw.setFont(font);

        // set pen color
        StdDraw.setPenColor(Color.WHITE);

        // draw title
        StdDraw.text(FIFTY, EIGHTY, "CS61B: The Game");

        // set font size and style for options
        font = new Font("Arial", Font.BOLD, SIXTEEN);
        StdDraw.setFont(font);

        // draw options
        StdDraw.text(FIFTY, FIFTY, "New Game (N)");
        StdDraw.text(FIFTY, FORTY, "Load Game (L)");
        StdDraw.text(FIFTY, THIRTY, "Quit (Q)");
        StdDraw.text(FIFTY, TWENTY, "Insert Avatar Name (A)");

        // show the canvas
        StdDraw.show();
    }
    public void drawBasicInputString() {
        StdDraw.setCanvasSize(SIXHUNDRED, SIXHUNDRED);
        // set x- and y-scales
        StdDraw.setXscale(0, ONEHUNDRED);
        StdDraw.setYscale(0, ONEHUNDRED);
        StdDraw.clear(Color.BLACK);

        // set font size and style
        Font font = new Font("Arial", Font.BOLD, SIXTY);
        StdDraw.setFont(font);

        // set pen color
        StdDraw.setPenColor(Color.WHITE);

        // draw title
        // set font size and style for options
        font = new Font("Arial", Font.BOLD, SIXTEEN);
        StdDraw.setFont(font);
    }

    public void drawRandomSeed() {
        StdDraw.clear(Color.BLACK);
        Font font = new Font("Arial", Font.BOLD, FORTY);
        StdDraw.setFont(font);
        StdDraw.text(FIFTY, EIGHTY, "Enter a random seed");
    }

    private Pairs processGame(KeyboardInputSource collin, String keys) {
        TETile[][] myloadedTile = new TETile[1][1];
        StdDraw.clear(Color.BLACK);
        Font font = new Font("Arial", Font.BOLD, FORTY);
        StdDraw.setFont(font);
        StdDraw.text(FIFTY, EIGHTY, "Enter a random seed");
        String curSeed = "";
        boolean rendered = false;
        while (!rendered) {
            char myChar = collin.getNextKey();
            keys += myChar;
            if (myChar != 'S') {
                curSeed = curSeed + myChar;
                StdDraw.clear(Color.BLACK);
                StdDraw.text(FIFTY, EIGHTY, curSeed);
            } else {
                Rooms myRooms = new Rooms(new TETile[WIDTH][HEIGHT], Long.parseLong(curSeed));
                myRooms.makeRooms();
                myRooms.addHallways();
                myRooms.findRandomTile();
                ter.initialize(myRooms.getTile().length, myRooms.getTile()[0].length);
                ter.renderFrame(myRooms.getTile());
                myloadedTile = myRooms.getTile();
                rendered = true;
            }
        }
        return new Pairs(myloadedTile, keys);
    }

    private Pairs loadGame() {
        Scanner scanner = null;
        try {
            scanner = new Scanner(new File("myfile.txt"));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        String hi = scanner.next();
        String keys = hi;
        TETile[][] myloadedTile = interactWithInputString(hi);
        ter.renderFrame(myloadedTile);
        return new Pairs(myloadedTile, keys);
    }

    private Pairs newOrLoad(KeyboardInputSource collin, String keys, char myChar) {
        if (myChar == 'L') {
            return loadGame();
        } else if (myChar == 'N') {
            return processGame(collin, keys);
        }
        return null;
    }

    private String avatarProcess(KeyboardInputSource collin) {
        StdDraw.clear(Color.BLACK);
        Font font = new Font("Arial", Font.BOLD, THIRTY);
        StdDraw.setFont(font);
        StdDraw.text(FIFTY, EIGHTY, "Enter a name, then press : to finish");
        String curName = "";
        boolean done = false;
        String avatarName = "";
        while (!done) {
            char myChar = collin.getNextKey();
            if (myChar != ':') {
                curName = curName + myChar;
                StdDraw.clear(Color.BLACK);
                StdDraw.text(FIFTY, EIGHTY, curName);
            } else {
                done = true;
                avatarName = curName;
            }
        }
        drawBasic();
        return avatarName;
    }

    public int[] checkAvatar(TETile[][] myloadedTile) {
        for (int i = 0; i < myloadedTile.length; i++) {
            for (int j = 0; j < myloadedTile[0].length; j++) {
                if (myloadedTile[i][j] == Tileset.AVATAR) {
                    avatarH = i;
                    avatarV = j;
                }
            }
        }
        int[] london = new int[2];
        london[0] = avatarH;
        london[1] = avatarV;
        return london;
    }

    public void writeFile(String keys) {
        FileWriter writer = null;
        try {
            writer = new FileWriter("myfile.txt");
            writer.write(keys.substring(0, keys.length()));
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void writeFileInputString(String hi, String thisString) {
        FileWriter writer = null;
        try {
            writer = new FileWriter("myfile.txt");
            writer.write(hi + thisString.substring(0, thisString.length() - 2));
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Complex processChar(char myChar, int vatarV, int vatarH,
                                    Rooms myRooms, TETile[][] myloadedTile, String keys, TETile[][] toggleTile) {
        boolean toggle = false;
        if (myChar == 'W') {
            vatarV = myRooms.moveUp(myloadedTile, vatarH, vatarV);
            ter.renderFrame(myloadedTile);
        } else if (myChar == 'A') {
            vatarH = myRooms.moveLeft(myloadedTile, vatarH, vatarV);
            ter.renderFrame(myloadedTile);
        } else if (myChar == 'S') {
            vatarV = myRooms.moveDown(myloadedTile, vatarH, vatarV);
            ter.renderFrame(myloadedTile);
        } else if (myChar == 'D') {
            vatarH = myRooms.moveRight(myloadedTile, vatarH, vatarV);
            ter.renderFrame(myloadedTile);
        } else if (myChar == 'T') {
            toggle = true;
            keys = keys.substring(0, keys.length() - 1);
            for (int i = 0; i < myloadedTile.length; i++) {
                for (int j = 0; j < myloadedTile[0].length; j++) {
                    if (Math.abs(vatarH - i) + Math.abs(vatarV - j) <= 5) {
                        toggleTile[i][j] = myloadedTile[i][j];
                    } else {
                        toggleTile[i][j] = Tileset.NOTHING;
                    }
                }
            }
            ter.renderFrame(toggleTile);
        }
        return new Complex(vatarH, vatarV, keys, toggle);
    }

    public Complex processCharToggled(char myChar, int vatarV, int vatarH,
                                           Rooms myRooms, TETile[][] myloadedTile, String keys, TETile[][] toggleTile) {
        boolean toggle = true;
        if (myChar == 'W') {
            vatarV = myRooms.moveUp(myloadedTile, vatarH, vatarV);
            for (int i = 0; i < myloadedTile.length; i++) {
                for (int j = 0; j < myloadedTile[0].length; j++) {
                    if (Math.abs(vatarH - i) + Math.abs(vatarV - j) <= 5) {
                        toggleTile[i][j] = myloadedTile[i][j];
                    } else {
                        toggleTile[i][j] = Tileset.NOTHING;
                    }
                }
            }
            ter.renderFrame(toggleTile);
        } else if (myChar == 'A') {
            vatarH = myRooms.moveLeft(myloadedTile, vatarH, vatarV);
            for (int i = 0; i < myloadedTile.length; i++) {
                for (int j = 0; j < myloadedTile[0].length; j++) {
                    if (Math.abs(vatarH - i) + Math.abs(vatarV - j) <= 5) {
                        toggleTile[i][j] = myloadedTile[i][j];
                    } else {
                        toggleTile[i][j] = Tileset.NOTHING;
                    }
                }
            }
            ter.renderFrame(toggleTile);
        } else if (myChar == 'S') {
            vatarV = myRooms.moveDown(myloadedTile, vatarH, vatarV);
            for (int i = 0; i < myloadedTile.length; i++) {
                for (int j = 0; j < myloadedTile[0].length; j++) {
                    if (Math.abs(vatarH - i) + Math.abs(vatarV - j) <= 5) {
                        toggleTile[i][j] = myloadedTile[i][j];
                    } else {
                        toggleTile[i][j] = Tileset.NOTHING;
                    }
                }
            }
            ter.renderFrame(toggleTile);
        } else if (myChar == 'D') {
            vatarH = myRooms.moveRight(myloadedTile, vatarH, vatarV);
            for (int i = 0; i < myloadedTile.length; i++) {
                for (int j = 0; j < myloadedTile[0].length; j++) {
                    if (Math.abs(vatarH - i) + Math.abs(vatarV - j) <= 5) {
                        toggleTile[i][j] = myloadedTile[i][j];
                    } else {
                        toggleTile[i][j] = Tileset.NOTHING;
                    }
                }
            }
            ter.renderFrame(toggleTile);
        } else if (myChar == 'T') {
            keys = keys.substring(0, keys.length() - 1);
            toggle = false;
            ter.renderFrame(myloadedTile);
        }
        return new Complex(vatarH, vatarV, keys, toggle);
    }
}
