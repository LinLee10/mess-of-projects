package ngordnet.wordnet;

import edu.princeton.cs.algs4.In;
import ngordnet.ngrams.NGramMap;
import org.junit.jupiter.api.Test;
import ngordnet.graphs.DirectedGraph;

import java.util.*;

import static com.google.common.truth.Truth.assertThat;

public class WordNetTestFile {

    public static final String BASIC_SYNSETS = "data/wordnet/synsets11.txt";
    public static final String BASIC_HYPONYMS = "data/wordnet/hyponyms11.txt";
    public static final String HARD_SYNSETS = "data/wordnet/synsets16.txt";
    public static final String HARD_HYPONYMS = "data/wordnet/hyponyms16.txt";
    public static final String MULTIPLE_SYNSETS = "data/wordnet/synsets7.txt";
    public static final String MULTIPLE_HYPONYMS = "data/wordnet/hyponyms7.txt";
    public static final String HYPONYMS = "data/wordnet/hyponyms.txt";
    public static final String SYNSETS = "data/wordnet/synsets.txt";
    public static final NGramMap NGRAM = new NGramMap("data/ngrams/top_14377_words.csv", "data/ngrams/total_counts.csv");

    @Test
    /** Tests if our constructor properly parses and stores data from files. */
    public void constructorTest() {
        WordNet net = new WordNet(BASIC_SYNSETS, BASIC_HYPONYMS, NGRAM);
        DirectedGraph<Integer> idGraph = new DirectedGraph<>();
        HashMap<Integer, String> idMap = new HashMap<>();
        HashMap<String, HashSet<Integer>> wordMap = new HashMap<>();

        // Set of connections for graph test.
        HashSet<Integer> set1 = new HashSet<>();
        HashSet<Integer> set2 = new HashSet<>();
        HashSet<Integer> set3 = new HashSet<>();
        HashSet<Integer> set4 = new HashSet<>();
        HashSet<Integer> set5 = new HashSet<>();

        // Constructs the initial idGraph.
        idGraph.addVertex(0, 1);
        idGraph.addEdge(1, 2);
        idGraph.addVertex(3, 4);
        idGraph.addVertex(5, 6);
        idGraph.addEdge(5, 7);
        idGraph.addVertex(8, 10);
        idGraph.addVertex(9, 10);

        // Tests if graph edges and vertices count works.
        assertThat(net.idGraphTest().verticesCount()).isEqualTo(11);
        assertThat(net.idGraphTest().edgesCount()).isEqualTo(7);

        // Tests connections for each vertex.
        set1.add(1);
        assertThat(net.idGraphTest().connections(0)).isEqualTo(set1);

        set2.add(2);
        assertThat(net.idGraphTest().connections(1)).isEqualTo(set2);

        set3.add(4);
        assertThat(net.idGraphTest().connections(3)).isEqualTo(set3);

        set4.add(6);
        set4.add(7);
        assertThat(net.idGraphTest().connections(5)).isEqualTo(set4);

        set5.add(10);
        assertThat(net.idGraphTest().connections(8)).isEqualTo(set5);
        assertThat(net.idGraphTest().connections(9)).isEqualTo(set5);

        // Constructs the initial idMap.
        idMap.put(0, "action");
        idMap.put(1, "change");
        idMap.put(2, "demotion");
        idMap.put(3, "descent");
        idMap.put(4, "jump parachuting");
        idMap.put(5, "increase");
        idMap.put(6, "jump leap");
        idMap.put(7, "augmentation");
        idMap.put(8, "antihistamine");
        idMap.put(9, "nasal_decongestant");
        idMap.put(10, "actifed");
        assertThat(net.idMapTest()).isEqualTo(idMap);

        // Constructs the initial wordMap.

        wordMap.put("action", new HashSet<Integer>(List.of(0)));
        wordMap.put("change", new HashSet<Integer>(List.of(1)));
        wordMap.put("demotion", new HashSet<Integer>(List.of(2)));
        wordMap.put("descent", new HashSet<Integer>(List.of(3)));
        wordMap.put("jump", new HashSet<Integer>(List.of(4, 6)));
        wordMap.put("parachuting", new HashSet<Integer>(List.of(4)));
        wordMap.put("increase", new HashSet<Integer>(List.of(5)));
        wordMap.put("leap", new HashSet<Integer>(List.of(6)));
        wordMap.put("augmentation", new HashSet<Integer>(List.of(7)));
        wordMap.put("antihistamine", new HashSet<Integer>(List.of(8)));
        wordMap.put("nasal_decongestant", new HashSet<Integer>(List.of(9)));
        wordMap.put("actifed", new HashSet<Integer>(List.of(10)));
        assertThat(net.wordMapTest()).isEqualTo(wordMap);
    }

    @Test
    /** Tests if getWord is able to retrieve a word using an id. */
    public void basicGetWordTest() {
        WordNet net = new WordNet(BASIC_SYNSETS, BASIC_HYPONYMS, NGRAM);
        In synsets = new In(BASIC_SYNSETS);

        while (!synsets.isEmpty()) {
            String[] line = synsets.readLine().split(",");
            int id = Integer.parseInt(line[0]);
            String word = line[1];
            assertThat(net.getWord(id)).isEqualTo(word);
        }

        int id = 3;
        String word = "descent";
        assertThat(net.getWord(id)).isEqualTo(word);
    }
}
