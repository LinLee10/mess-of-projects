package byow.Core;

public class Complex {
    private int avatarH;
    private int avatarV;
    private String keyString;
    private boolean toggle;

    public Complex(int avatarH, int avatarV, String keyString, boolean toggle) {
        this.avatarH = avatarH;
        this.avatarV = avatarV;
        this.keyString = keyString;
        this.toggle = toggle;
    }

    public int getAvatarH() {
        return avatarH;
    }

    public int getAvatarV() {
        return avatarV;
    }

    public String getKeyString() {
        return keyString;
    }
    public boolean getToggle() {
        return toggle;
    }
}
