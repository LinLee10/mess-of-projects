package ngordnet.graphs;

import org.junit.jupiter.api.Test;

import java.util.HashMap;

import static com.google.common.truth.Truth.assertThat;

/** More of an experimental test file, for us to tests nested data structures. */
public class DirectedGraphsComplexTestFile {

    @Test
    /** Tests if adding another data structure as a vertex is reasonable.
     *  One downside to this is that you need the pre-existing data structure in order to access values. */
    public void addDataStructureVertex() {
        DirectedGraph<HashMap<Integer, String>> graph = new DirectedGraph<>();
        HashMap<Integer, String> map = new HashMap<>();
        HashMap<Integer, String> imposter = new HashMap<>();

        map.put(1, "cat");
        graph.addVertex(map);
        assertThat(graph.containsVertex(map)).isTrue();
        assertThat(graph.containsVertex(imposter)).isFalse();

        imposter.put(1, "cat");
        assertThat(graph.containsVertex(imposter)).isTrue();
    }

    @Test
    /** Tests if connecting two data structures together is reasonable.
     *  Still need the pre-existing data structures to add a vertex. */
    public void addDataStructureEdge() {
        DirectedGraph<HashMap<Integer, String>> graph = new DirectedGraph<>();
        HashMap<Integer, String> map1 = new HashMap<>();
        HashMap<Integer, String> map2 = new HashMap<>();

        map1.put(1, "cat");
        map2.put(2, "dog");
        graph.addVertex(map1);
        graph.addVertex(map2);
        graph.addEdge(map1, map2);
        assertThat(graph.isConnected(map1, map2)).isTrue();
    }
}
